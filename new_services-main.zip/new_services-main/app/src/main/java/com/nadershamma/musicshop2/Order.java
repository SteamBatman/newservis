package com.nadershamma.musicshop2;

public class Order {
    String userName;
    String goodsName;
    int quantity;
    double orderPrice;

}
